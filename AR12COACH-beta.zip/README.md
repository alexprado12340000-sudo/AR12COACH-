# AR12 COACH — Beta de teste
TRAIL RUN · EVOLVE

Inclui GPS via navegador, iniciar/pausar/retomar/finalizar, distância, pace, velocidade, traçado da rota, histórico local, configurações e PWA.

## Importante
Para GPS real, publique em HTTPS e permita localização no celular. Nesta primeira beta, mantenha o app/tela ativo durante a corrida; gravação robusta em segundo plano exige etapa nativa posterior.
